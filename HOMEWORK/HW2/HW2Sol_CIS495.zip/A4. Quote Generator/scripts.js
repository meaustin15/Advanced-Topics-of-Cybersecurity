var quotes = [
	'You will learn more from failure than from success. -Zahid',
	'The way to get started is to quit talking and begin doing. -Walt Disney'
]

function newQuote()
{
	var randomNumber = Math.floor(Math.random() * (quotes.length));
	document.getElementById('quoteDisplay').innerHTML = quotes[randomNumber];
}
