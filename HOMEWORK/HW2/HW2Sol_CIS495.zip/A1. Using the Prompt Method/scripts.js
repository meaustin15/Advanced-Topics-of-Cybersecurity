var visitor = prompt('What is your name?');
var message = 'Hello ' + visitor + '. Welcome to Fontbonne.';
message += "We are so glad that you came by to visit, ";
message += visitor;
message += '. Please come again, when you want to learn some more.';
document.write(message);